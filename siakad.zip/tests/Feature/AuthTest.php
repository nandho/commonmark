<?php

namespace Tests\Feature;

use Tests\TestCase;

class AuthTest extends TestCase
{
    public function testingTest(): void
    {
        self::assertTrue(true);
    }
}
