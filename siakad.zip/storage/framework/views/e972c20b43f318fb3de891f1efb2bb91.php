<?php $__env->startSection('title', 'Detail Semester'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full p-6 mx-auto">
  <!-- Tempat untuk menampilkan detail semester -->
  <div id="detailSemester" class="bg-white p-6 rounded-lg shadow-lg">
    <!-- Data semester akan di-render di sini oleh Axios -->
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    var semesterId = '<?php echo e($id); ?>'; // ID yang diterima dari controller
    var detailContainer = document.getElementById('detailSemester');

    axios.get('http://localhost:9000/api/Semester/' + semesterId)
      .then(function(response) {
        // Menangani sukses
        var semester = response.data;
        detailContainer.innerHTML = `
          <h2 class="text-xl font-semibold mb-2">${semester.nama_semester}</h2>
          <p><strong>ID:</strong> ${semester.id}</p>
          <p><strong>Tanggal Mulai:</strong> ${semester.tanggal_mulai}</p>
          <p><strong>Tanggal Selesai:</strong> ${semester.tanggal_selesai}</p>
          <p><strong>Status:</strong> ${semester.status}</p>
        `;
      })
      .catch(function(error) {
        // Menangani error
        console.error(error);
      });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad\resources\views/semester_detail.blade.php ENDPATH**/ ?>